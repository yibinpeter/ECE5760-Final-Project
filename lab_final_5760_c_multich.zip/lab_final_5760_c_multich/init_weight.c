#include "weight_array.h"

int8_t weight[8][3][3];  // 实际定义数组

int main() {
    weight[0][0][0] = -1;
    weight[0][0][1] = 0;
    weight[0][0][2] = 1;

    weight[0][1][0] = -2;
    weight[0][1][1] = 0;
    weight[0][1][2] = 2;

    weight[0][2][0] = -1;
    weight[0][2][1] = 0;
    weight[0][2][2] = 1;

    // 初始化数组
    for (int img = 1; img < 8; img++) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                weight[img][i][j] = 0; 
            }
        }
    }
    
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                printf("%d ", weight[img][i][j]);
            }
            printf("\n");
        }
        printf("\n");
    }
}