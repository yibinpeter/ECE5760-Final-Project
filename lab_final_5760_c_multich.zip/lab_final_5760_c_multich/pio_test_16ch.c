///////////////////////////////////////
/// 640x480 version!
/// test VGA with hardware video input copy to VGA
// compile with
// gcc pio_test_1.c -o pio 
// gcc init_weight.c convert_graph.c pio_test.c -o program
// gcc init_weight.c convert_graph.c padding_zero.c pio_test.c -o program
///////////////////////////////////////
#define _POSIX_C_SOURCE 199309L
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/mman.h>
#include <sys/time.h> 
#include <math.h> 

#include <time.h>
// network stuff
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <errno.h> // For error handling
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <ctype.h>

#include "data_array.h" // data input_channel_group*original_size*original_size * 1 * 8bits
#include "weight_array.h" // input_channel_group* ch_in_gp * kernel_size * kernel_size * 8bits

// main bus; PIO
#define FPGA_AXI_BASE 	0xC0000000
#define FPGA_AXI_SPAN   0x00001000
// main axi bus base
void *h2p_virtual_base;
volatile unsigned int * axi_pio_ptr = NULL ;
volatile unsigned int * axi_pio_read_ptr = NULL ;

volatile unsigned int * axi_pio_main_low_out_ptr = NULL ;
volatile unsigned int * axi_pio_main_high_out_ptr = NULL ;

// lw bus; PIO
#define FPGA_LW_BASE 	0xff200000
#define FPGA_LW_SPAN	0x00001000
// the light weight bus base
void *h2p_lw_virtual_base;
// HPS_to_FPGA FIFO status address = 0
volatile unsigned int * axi_pio_lw_valid_ptr = NULL ;
volatile unsigned int * axi_pio_lw_request_ptr = NULL ;

volatile unsigned int * axi_pio_lw_ifm_curr_ptr = NULL ; // 1b
volatile unsigned int * axi_pio_lw_wet_curr_ptr = NULL ; // 1b
volatile unsigned int * axi_pio_lw_ifm_done_ptr = NULL ; // 1b
volatile unsigned int * axi_pio_lw_ifm_wr_ptr = NULL ; // 16bit
volatile unsigned int * axi_pio_lw_wet_wr_ptr = NULL ; // 16bit
volatile unsigned int * axi_pio_lw_thr_ptr = NULL ; // 16bit
volatile unsigned int * axi_pio_lw_buf_ack_ptr = NULL ; // 1bit


// read offset is 0x10 for both busses
// remember that eaxh axi master bus needs unique address
// MAIN
#define FPGA_PIO_MAIN_LOW_OUT	0x00
#define FPGA_PIO_MAIN_HIGH_OUT	0x10
// LW
#define FPGA_PIO_LW_VALID_OUT	0x00
#define FPGA_PIO_LW_REQUEST_IN	0x10

#define FPGA_PIO_LW_IFM_CURR_OUT	0x20
#define FPGA_PIO_LW_WET_CURR_OUT	0x30
#define FPGA_PIO_LW_IFM_done_OUT	0x40
#define FPGA_PIO_LW_IFM_WR_OUT	0x50
#define FPGA_PIO_LW_WET_WR_OUT	0x60
#define FPGA_PIO_LW_THR_OUT     0x70
#define FPGA_PIO_LW_BUF_ACK  0x80

#define DEBUG_PRINT_INIT 0
#define DEBUG_SEND 0

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "data_array.h"
#include "weight_array.h"

#define ch_in_gp 8
#define padding_layer 1
#define original_size 28  // 原始图像尺寸
#define kernel_size 3
#define input_channel_group 2 // 2*8=16ch
#define output_channel_num 2 // 2ch out
#define HIGH_TH 200
#define LOW_TH  0
#define TH_STEP 5
        
int8_t weight[input_channel_group+output_channel_num][ch_in_gp][kernel_size][kernel_size];  // 实际定义数组
uint8_t data[input_channel_group][ch_in_gp][original_size][original_size];  // 实际定义数组
uint8_t padded_data[input_channel_group][ch_in_gp][original_size + padding_layer * 2][original_size + padding_layer * 2];
// /dev/mem file id
int fd;	

int init_weight(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open file");
        return 1;
    }
    for (int out_ch = 0; out_ch < output_channel_num; out_ch++) {
      for (int i = 0; i < input_channel_group; i++) {
          for (int j = 0; j < ch_in_gp; j++) {
              for (int k = 0; k < kernel_size; k++) {
                  for (int l = 0; l < kernel_size; l++) {
                      // 读取单个整数，并检查是否读取成功
                      if (fscanf(file, "%hhd", &weight[i+out_ch*2][j][k][l]) != 1) {
                          fprintf(stderr, "Error reading weight file at position %d,%d,%d,%d\n", i+out_ch*2, j, k, l);
                          fclose(file);
                          return 1;
                      }
                  }
              }
          }
      }
    }
    
    fclose(file);

    if (DEBUG_PRINT_INIT){
      for (int out_ch = 0; out_ch < output_channel_num; out_ch++) {
        for (int i = 0; i < input_channel_group; i++) {
              for (int j = 0; j < ch_in_gp; j++) {
                  printf("Matrix %d-%d:\n", i, j);
                  for (int k = 0; k < kernel_size; k++) {
                      for (int l = 0; l < kernel_size; l++) {
                          printf("%d ", weight[i+out_ch*2][j][k][l]);
                      }
                      printf("\n");
                  }
                  printf("\n");
              }
          }
      }
    }
    return 0;
}

void initialize_padded_data() {
    // 初始化所有元素为0
    for (int gp = 0; gp < input_channel_group; gp++) {
        for (int img = 0; img < ch_in_gp; img++) {
            for (int i = 0; i < original_size + padding_layer * 2; i++) {
                for (int j = 0; j < original_size + padding_layer * 2; j++) {
                    padded_data[gp][img][i][j] = 0; // 0
                }
            }
        }
    }
    
    // 将原始数据复制到padded_data的中心
    for (int gp = 0; gp < input_channel_group; gp++) {
        for (int img = 0; img < ch_in_gp; img++) {
            for (int i = 0; i < original_size; i++) {
                for (int j = 0; j < original_size; j++) {
                    padded_data[gp][img][i + padding_layer][j + padding_layer] = data[gp][img][i][j];
                }
            }
        }
    }
}


void print_padded_data() {
    // 打印第一张图的填充数据
    for (int i = 0; i < original_size + padding_layer * 2; i++) {
        for (int j = 0; j < original_size + padding_layer * 2; j++) {
            printf("%3d ", padded_data[0][0][i][j]);
        }
        printf("\n");
    }
    printf("--------------------------------------------------------\n");
    for (int i = 0; i < original_size + padding_layer * 2; i++) {
        for (int j = 0; j < original_size + padding_layer * 2; j++) {
            printf("%3d ", padded_data[1][0][i][j]);
        }
        printf("\n");
    }
}

// 定义函数来读取数组
int readArrayFromFile(const char *filename) {
    FILE *file;
  
    // 打开文件
    file = fopen(filename, "r");
    if (file == NULL) {
        perror("打开文件失败");
        return 1; // 返回1表示失败
    }

    int value;
    for (int group = 0; group < input_channel_group; group++) {
        for (int channel = 0; channel < ch_in_gp; channel++) {
            for (int row = 0; row < original_size; row++) {
                for (int col = 0; col < original_size; col++) {
                    // 读取单个整数
                    if (fscanf(file, "%d", &value) != 1) {
                        fprintf(stderr, "Error reading ifm file at group %d, channel %d, row %d, col %d\n", group, channel, row, col);
                        fclose(file);
                        return 1;
                    }
                    data[group][channel][row][col] = (uint8_t)value;
                }
            }
        }
    }
    
    return 0; // 返回0表示成功
}

void print_bits(uint32_t num) {
    for (int i = 31; i >= 0; i--) {  // 从最高位到最低位
        printf("%u", (num >> i) & 1);  // 右移i位，并与1进行AND操作，结果为该位的值（0或1）
        if (i % 8 == 0 && i != 0) {  // 每8位输出一个空格，增加可读性
            printf(" ");
        }
    }
    printf("\n");
}

int main(void)
{   
    //----------------------------------------------------
    int user_sleep_rate;
    // read file
    printf("give me a sleep_rate in ns: ");
    scanf("%d", &user_sleep_rate);
    printf("\n user_sleep_rate is %d \n", user_sleep_rate);
    //----------------------------------------------------
    struct timespec req, rem;
    req.tv_sec = 0;           // 0 seconds
    req.tv_nsec = 1 * user_sleep_rate; // 1,000,000 nanoseconds (1000 us) (1ms)
    //----------------------------------------------------
    char ifm_file[100];
    char ifm_file_path[120];
    printf("Please enter the ifm file: "); 
    scanf("%99s", ifm_file);
    sprintf(ifm_file_path, "0_txt/%s.txt", ifm_file);
    printf("\nThe file is: %s\n", ifm_file_path);
    //----------------------------------------------------
    char weight_file[100];
    char weight_file_path[120];
    printf("Please enter the weight file: "); 
    scanf("%99s", weight_file);
    sprintf(weight_file_path, "0_txt/%s.txt", weight_file);
    printf("\nThe file is: %s\n", weight_file_path);
    //----------------------------------------------------
    int user_threshold;
    printf("give me a threshold: ");
    scanf("%d", &user_threshold);
    printf("\n threshold is %d", user_threshold);
    //----------------------------------------------------

    int result_weight;
    // read file
    result_weight = init_weight(weight_file_path);
    if (result_weight != 0) {
        printf("Failed to read file weight\n");
        return 1;
    }
    //----------------------------------------------------
    
    int result_ifm;
    // read file
    result_ifm = readArrayFromFile(ifm_file_path);
    if (result_ifm != 0) {
        printf("Failed to read file ifm\n");
        return 1;
    }
    if (DEBUG_PRINT_INIT){
        for (int gp = 0; gp < input_channel_group; gp++) {
            for (int imgs = 0; imgs < ch_in_gp; imgs++) {
                for (int i = 0; i < original_size; i++) {
                    for (int j = 0; j < original_size; j++) {
                        printf("%d ", data[gp][imgs][i][j]);
                    }
                    printf("\n");
                }
                printf("\n");
            }
            printf("\n");
        }
    }
    
    initialize_padded_data();
    if (DEBUG_PRINT_INIT) print_padded_data();
	// Declare volatile pointers to I/O registers (volatile 	
	// means that IO load and store instructions will be used 	
	// to access these pointer locations,  
  
	// === get FPGA addresses ==================
    // Open /dev/mem
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) 	{
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
    
	//============================================
    // get virtual addr that maps to physical
	// for light weight AXI bus
	h2p_lw_virtual_base = mmap( NULL, FPGA_LW_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_LW_BASE );	
	if( h2p_lw_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap1() failed...\n" );
		close( fd );
		return(1);
	}
	// Get the addresses that map to the two parallel ports on the light-weight bus
	axi_pio_lw_valid_ptr = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_VALID_OUT);
	axi_pio_lw_request_ptr = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_REQUEST_IN);
	*(axi_pio_lw_valid_ptr) = 0;
 
    axi_pio_lw_ifm_curr_ptr  = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_IFM_CURR_OUT);
    axi_pio_lw_wet_curr_ptr  = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_WET_CURR_OUT);
    axi_pio_lw_ifm_done_ptr  = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_IFM_done_OUT);
    axi_pio_lw_ifm_wr_ptr    = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_IFM_WR_OUT);
    axi_pio_lw_wet_wr_ptr    = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_WET_WR_OUT);
    axi_pio_lw_thr_ptr       = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_THR_OUT);
    axi_pio_lw_buf_ack_ptr=(unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_BUF_ACK);
  
    *(axi_pio_lw_ifm_curr_ptr) = 0;
    *(axi_pio_lw_wet_curr_ptr) = 0;
    *(axi_pio_lw_ifm_done_ptr) = 0;
    *(axi_pio_lw_ifm_wr_ptr) = 0;
    *(axi_pio_lw_wet_wr_ptr) = 0;
    *(axi_pio_lw_thr_ptr) = user_threshold;
	//===========================================
	
	// ===========================================
	// get virtual address for
	// AXI bus addr 
	h2p_virtual_base = mmap( NULL, FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_AXI_BASE); 	
	if( h2p_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}
    // Get the addresses that map to the two parallel ports on the AXI bus
    axi_pio_main_low_out_ptr  = (unsigned int *)(h2p_virtual_base + FPGA_PIO_MAIN_LOW_OUT);
    axi_pio_main_high_out_ptr = (unsigned int *)(h2p_virtual_base + FPGA_PIO_MAIN_HIGH_OUT);
	//============================================
	
	printf("\n DEBUG: map successfully");
    int in_animate_lopp  = 1;
    int up_mode = 1;
    int trigger_one_buf_ack = 0;
    // int output_channel_num = 2;
    // int output_channel_count = 0;
    while (in_animate_lopp) {
        //printf("trigger1");
        for (int output_channel_count = 0; output_channel_count < output_channel_num; output_channel_count++) {
          //printf("trigger2");
          for (int gp = 0; gp < input_channel_group; gp++){
              while ((*(axi_pio_lw_request_ptr)) == 0) { ; }
              //printf("trigger1111!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
              if(!(*(axi_pio_lw_request_ptr)) == 0){
                  //printf("trigger");
                  *(axi_pio_lw_ifm_curr_ptr) = 1;
                  for (int i = 0; i < original_size+padding_layer*2; i++) {
                      for (int j = 0; j < original_size+padding_layer*2; j++) {
                          uint64_t data_to_send = 0;
                          for (int imgs = 0; imgs < ch_in_gp; imgs++) {
                              data_to_send |= ((uint64_t)padded_data[gp][imgs][i][j]) << (imgs * 8);
                          }
                          *axi_pio_main_low_out_ptr = (uint32_t)(data_to_send & 0xFFFFFFFF);   // 发低32位
                          *axi_pio_main_high_out_ptr = (uint32_t)(data_to_send >> 32);         // 发高32位
                          *axi_pio_lw_ifm_wr_ptr = (uint16_t)(i*(original_size+padding_layer*2)+j);
                          if (DEBUG_SEND){
                              printf("ifm write addr: %u\n", (uint16_t)(i*(original_size+padding_layer*2)+j));
                              printf("Integer format: %u\n", (uint32_t)(data_to_send & 0xFFFFFFFF));
                              printf("Bit format:     ");
                              print_bits((uint32_t)(data_to_send & 0xFFFFFFFF));
                              printf("Integer format: %u\n", (uint32_t)(data_to_send >> 32));
                              printf("Bit format:     ");
                              print_bits((uint32_t)(data_to_send >> 32));
                          }
                          //while (nanosleep(&req, &rem) == -1 && errno == EINTR) req = rem;	
                          //sleep(0.1);
                      }
                  }
                  *(axi_pio_lw_ifm_curr_ptr) = 0;
                  sleep(0.1);
                  *axi_pio_lw_ifm_wr_ptr = (uint16_t)(0);
                  sleep(0.1);
  
                  // weight
                  *(axi_pio_lw_wet_curr_ptr) = 1;
                  for (int i = 0; i < kernel_size; i++) {
                      for (int j = 0; j < kernel_size; j++) {
                          //*(axi_pio_lw_valid_ptr) = 0 ;
                          uint64_t data_to_send = 0;
                          for (int imgs = 0; imgs < ch_in_gp; imgs++) {
                              data_to_send |= ((uint64_t)weight[gp+output_channel_count*2][imgs][i][j]) << (imgs * 8);
                          }
                          *axi_pio_main_low_out_ptr = (uint32_t)(data_to_send & 0xFFFFFFFF);   // 发低32位
                          *axi_pio_main_high_out_ptr = (uint32_t)(data_to_send >> 32);         // 发高32位
                          *axi_pio_lw_wet_wr_ptr = (uint16_t)(i*kernel_size+j);
                          if (DEBUG_SEND) {
                              printf("weight write addr: %u\n", (uint16_t)(i*kernel_size+j));
                              printf("Integer format: %u\n", (uint32_t)(data_to_send & 0xFFFFFFFF));
                              printf("Bit format:     ");
                              print_bits((uint32_t)(data_to_send & 0xFFFFFFFF));
                              printf("Integer format: %u\n", (uint32_t)(data_to_send >> 32));
                              printf("Bit format:     ");
                              print_bits((uint32_t)(data_to_send >> 32));
                          }
                          //while (nanosleep(&req, &rem) == -1 && errno == EINTR) req = rem;	
                          //sleep(0.1);
                      }
                      
                  }
                  *(axi_pio_lw_wet_curr_ptr) = 0;
                  sleep(0.1);
                  *axi_pio_lw_wet_wr_ptr = (uint16_t)(0);
                  sleep(0.1);
                  *(axi_pio_lw_ifm_done_ptr) = 1;
                  // sleep(0.1);
                  //if (!trigger_one_buf_ack) {
                    // printf("trigger waiting for buf ack");
                    while (*(axi_pio_lw_buf_ack_ptr) != 1) {printf("waiting");}
                    *(axi_pio_lw_ifm_done_ptr) = 0;
                    trigger_one_buf_ack = 1;
                  //}
              }
  
          }
        
        }
        in_animate_lopp = 1;
        if (up_mode) user_threshold = user_threshold + TH_STEP;
        else user_threshold = user_threshold - TH_STEP;
            
        if (user_threshold < (HIGH_TH+TH_STEP+5) && user_threshold > (HIGH_TH)) up_mode = 0;
        else if (user_threshold > (LOW_TH) && user_threshold < (LOW_TH+TH_STEP+5) ) up_mode = 1;

        
        *(axi_pio_lw_thr_ptr) = user_threshold;
        //printf("\nTH: %d\n", user_threshold);
        //while (nanosleep(&req, &rem) == -1 && errno == EINTR) req = rem;	
        //printf("\ntrrrrrrrrrrr\n");
    }
        	
} // end main

/// /// ///////////////////////////////////// 
/// end /////////////////////////////////////