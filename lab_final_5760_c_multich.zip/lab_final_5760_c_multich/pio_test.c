///////////////////////////////////////
/// 640x480 version!
/// test VGA with hardware video input copy to VGA
// compile with
// gcc pio_test_1.c -o pio 
// gcc init_weight.c convert_graph.c pio_test.c -o program
// gcc init_weight.c convert_graph.c padding_zero.c pio_test.c -o program
///////////////////////////////////////
#define _POSIX_C_SOURCE 199309L
#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/mman.h>
#include <sys/time.h> 
#include <math.h> 

#include <time.h>
// network stuff
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <errno.h> // For error handling
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>
#include <ctype.h>

#include "data_array.h" // data original_size*original_size*1 * 8bits
#include "weight_array.h" // 8 * 3 * 3 * 8bits

// main bus; PIO
#define FPGA_AXI_BASE 	0xC0000000
#define FPGA_AXI_SPAN   0x00001000
// main axi bus base
void *h2p_virtual_base;
volatile unsigned int * axi_pio_ptr = NULL ;
volatile unsigned int * axi_pio_read_ptr = NULL ;

volatile unsigned int * axi_pio_main_low_out_ptr = NULL ;
volatile unsigned int * axi_pio_main_high_out_ptr = NULL ;

// lw bus; PIO
#define FPGA_LW_BASE 	0xff200000
#define FPGA_LW_SPAN	0x00001000
// the light weight bus base
void *h2p_lw_virtual_base;
// HPS_to_FPGA FIFO status address = 0
volatile unsigned int * axi_pio_lw_valid_ptr = NULL ;
volatile unsigned int * axi_pio_lw_request_ptr = NULL ;

volatile unsigned int * axi_pio_lw_ifm_curr_ptr = NULL ; // 1b
volatile unsigned int * axi_pio_lw_wet_curr_ptr = NULL ; // 1b
volatile unsigned int * axi_pio_lw_ifm_done_ptr = NULL ; // 1b
volatile unsigned int * axi_pio_lw_ifm_wr_ptr = NULL ; // 16bit
volatile unsigned int * axi_pio_lw_wet_wr_ptr = NULL ; // 16bit
volatile unsigned int * axi_pio_lw_thr_ptr = NULL ; // 16bit

// read offset is 0x10 for both busses
// remember that eaxh axi master bus needs unique address
// MAIN
#define FPGA_PIO_MAIN_LOW_OUT	0x00
#define FPGA_PIO_MAIN_HIGH_OUT	0x10
// LW
#define FPGA_PIO_LW_VALID_OUT	0x00
#define FPGA_PIO_LW_REQUEST_IN	0x10

#define FPGA_PIO_LW_IFM_CURR_OUT	0x20
#define FPGA_PIO_LW_WET_CURR_OUT	0x30
#define FPGA_PIO_LW_IFM_done_OUT	0x40
#define FPGA_PIO_LW_IFM_WR_OUT	0x50
#define FPGA_PIO_LW_WET_WR_OUT	0x60
#define FPGA_PIO_LW_THR_OUT     0x70

#define DEBUG_PRINT_INIT 1
#define DEBUG_SEND 1

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "data_array.h"
#include "weight_array.h"


#define padding_layer 1
#define original_size 28  // 原始图像尺寸

int8_t weight[8][3][3];  // 实际定义数组
uint8_t data[8][original_size][original_size];  // 实际定义数组
uint8_t padded_data[8][original_size + padding_layer * 2][original_size + padding_layer * 2];
// /dev/mem file id
int fd;	

void init_weight(){
//    weight[0][0][0] = 1;
//    weight[0][0][1] = 2;
//    weight[0][0][2] = 1;
//
//    weight[0][1][0] = 2;
//    weight[0][1][1] = 4;
//    weight[0][1][2] = 2;
//
//    weight[0][2][0] = 1;
//    weight[0][2][1] = 2;
//    weight[0][2][2] = 1;

     weight[0][0][0] = 0;
     weight[0][0][1] = 0;
     weight[0][0][2] = 0;
 
     weight[0][1][0] = 0;
     weight[0][1][1] = 1;
     weight[0][1][2] = 0;
 
     weight[0][2][0] = 0;
     weight[0][2][1] = 0;
     weight[0][2][2] = 0;
     
     
     weight[1][0][0] = 0;
     weight[1][0][1] = 0;
     weight[1][0][2] = 0;
 
     weight[1][1][0] = 0;
     weight[1][1][1] = 1;
     weight[1][1][2] = 0;
 
     weight[1][2][0] = 0;
     weight[1][2][1] = 0;
     weight[1][2][2] = 0;

    // 初始化数组
    for (int img = 2; img < 8; img++) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                weight[img][i][j] = 0; 
            }
        }
    }
    if (DEBUG_PRINT_INIT){
      for (int img = 0; img < 8; img++) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                printf("%d ", weight[img][i][j]);
            }
            printf("\n");
        }
        printf("\n");
      }
    }
    
}

void initialize_padded_data() {
    // 初始化所有元素为0
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < original_size + padding_layer * 2; i++) {
            for (int j = 0; j < original_size + padding_layer * 2; j++) {
                padded_data[img][i][j] = 0; // 0
            }
        }
    }

    // 将原始数据复制到padded_data的中心
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < original_size; i++) {
            for (int j = 0; j < original_size; j++) {
                padded_data[img][i + padding_layer][j + padding_layer] = data[img][i][j];
            }
        }
    }
}


void print_padded_data() {
    // 打印第一张图的填充数据
    for (int i = 0; i < original_size + padding_layer * 2; i++) {
        for (int j = 0; j < original_size + padding_layer * 2; j++) {
            printf("%3d ", padded_data[0][i][j]);
        }
        printf("\n");
    }
}

// 定义函数来读取数组
int readArrayFromFile(const char *filename1, const char *filename2) {
    FILE *file1;
  

    // 打开文件
    file1 = fopen(filename1, "r");
    if (file1 == NULL) {
        perror("打开文件失败");
        return 1; // 返回1表示失败
    }

    // 读取数据到二维数组
    for (int i = 0; i < original_size; i++) {
        for (int j = 0; j < original_size; j++) {
            if (fscanf(file1, "%d", &data[0][i][j]) != 1) {
                perror("文件读取错误");
                fclose(file1);
                return 1; // 返回1表示失败
            }
        }
    }

    // 关闭文件
    fclose(file1);

    FILE *file2;
 

    // 打开文件
    file2 = fopen(filename2, "r");
    if (file2 == NULL) {
        perror("打开文件失败");
        return 1; // 返回1表示失败
    }

    // 读取数据到二维数组
    for (int i = 0; i < original_size; i++) {
        for (int j = 0; j < original_size; j++) {
            if (fscanf(file2, "%d", &data[1][i][j]) != 1) {
                perror("文件读取错误");
                fclose(file2);
                return 1; // 返回1表示失败
            }
        }
    }

    // 关闭文件
    fclose(file2);

    for (int imgs = 2; imgs < 8; imgs++) {
        for (int i = 0; i < original_size; i++) {
            for (int j = 0; j < original_size; j++) {
                data[imgs][i][j] = 0;
            }
        }
    }
    
    return 0; // 返回0表示成功
}

void print_bits(uint32_t num) {
    for (int i = 31; i >= 0; i--) {  // 从最高位到最低位
        printf("%u", (num >> i) & 1);  // 右移i位，并与1进行AND操作，结果为该位的值（0或1）
        if (i % 8 == 0 && i != 0) {  // 每8位输出一个空格，增加可读性
            printf(" ");
        }
    }
    printf("\n");
}

int main(void)
{   
    struct timespec req, rem;
    req.tv_sec = 0;           // 0 seconds
    req.tv_nsec = 1 * 1000000L; // 1,000,000 nanoseconds (1000 us) (1ms)

    char filename1[100];
    char fullpath1[120];
    printf("Please enter the filename1: "); 
    scanf("%99s", filename1);
    sprintf(fullpath1, "0_txt/%s.txt", filename1);

    printf("\nThe file is: %s\n", fullpath1);
    
    char filename2[100];
    char fullpath2[120];
    printf("Please enter the filename2: "); 
    scanf("%99s", filename2);
    sprintf(fullpath2, "0_txt/%s.txt", filename2);

    printf("\nThe file is: %s\n", fullpath2);

    int user_threshold;
    printf("give me a threshold: ");
    scanf("%d", &user_threshold);
    
    printf("\n threshold is %d", user_threshold);
    int result;

    // read file
    result = readArrayFromFile(fullpath1, fullpath2);
    
    if (result != 0) {
        printf("Failed to read file\n");
        return 1;
    }
    if (DEBUG_PRINT_INIT){
      for (int imgs = 0; imgs < 8; imgs++) {
        for (int i = 0; i < original_size; i++) {
            for (int j = 0; j < original_size; j++) {
                printf("%d ", data[imgs][i][j]);
            }
            printf("\n");
        }
        printf("\n");
      }
    }
    
    initialize_padded_data();
    if (DEBUG_PRINT_INIT) print_padded_data();
    init_weight();
	// Declare volatile pointers to I/O registers (volatile 	
	// means that IO load and store instructions will be used 	
	// to access these pointer locations,  
  
	// === get FPGA addresses ==================
    // Open /dev/mem
	if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) 	{
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}
    
	//============================================
    // get virtual addr that maps to physical
	// for light weight AXI bus
	h2p_lw_virtual_base = mmap( NULL, FPGA_LW_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_LW_BASE );	
	if( h2p_lw_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap1() failed...\n" );
		close( fd );
		return(1);
	}
	// Get the addresses that map to the two parallel ports on the light-weight bus
	axi_pio_lw_valid_ptr = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_VALID_OUT);
	axi_pio_lw_request_ptr = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_REQUEST_IN);
	*(axi_pio_lw_valid_ptr) = 0;
 
    axi_pio_lw_ifm_curr_ptr  = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_IFM_CURR_OUT);
    axi_pio_lw_wet_curr_ptr  = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_WET_CURR_OUT);
    axi_pio_lw_ifm_done_ptr  = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_IFM_done_OUT);
    axi_pio_lw_ifm_wr_ptr    = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_IFM_WR_OUT);
    axi_pio_lw_wet_wr_ptr    = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_WET_WR_OUT);
    axi_pio_lw_thr_ptr       = (unsigned int *)(h2p_lw_virtual_base + FPGA_PIO_LW_THR_OUT);
  
    *(axi_pio_lw_ifm_curr_ptr) = 0;
    *(axi_pio_lw_wet_curr_ptr) = 0;
    *(axi_pio_lw_ifm_done_ptr) = 0;
    *(axi_pio_lw_ifm_wr_ptr) = 0;
    *(axi_pio_lw_wet_wr_ptr) = 0;
    *(axi_pio_lw_thr_ptr) = user_threshold;
	//===========================================
	
	// ===========================================
	// get virtual address for
	// AXI bus addr 
	h2p_virtual_base = mmap( NULL, FPGA_AXI_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, FPGA_AXI_BASE); 	
	if( h2p_virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap3() failed...\n" );
		close( fd );
		return(1);
	}
    // Get the addresses that map to the two parallel ports on the AXI bus
    axi_pio_main_low_out_ptr  = (unsigned int *)(h2p_virtual_base + FPGA_PIO_MAIN_LOW_OUT);
    axi_pio_main_high_out_ptr = (unsigned int *)(h2p_virtual_base + FPGA_PIO_MAIN_HIGH_OUT);
	//============================================
	
	printf("\n DEBUG: map successfully");
    int in_animate_lopp  = 1;
    int up_mode = 1;
    while (in_animate_lopp) {
        printf("%d\n", *(axi_pio_lw_request_ptr));
        while ((*(axi_pio_lw_request_ptr)) == 0) {
            ;
        }
        printf("trigger1111!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");

        if(!(*(axi_pio_lw_request_ptr)) == 0){
            printf("trigger");
            *(axi_pio_lw_ifm_curr_ptr) = 1;
            for (int i = 0; i < original_size+padding_layer*2; i++) {
                for (int j = 0; j < original_size+padding_layer*2; j++) {
                    uint64_t data_to_send = 0;
                    for (int imgs = 0; imgs < 8; imgs++) {
                        data_to_send |= ((uint64_t)padded_data[imgs][i][j]) << (imgs * 8);
                    }
                    *axi_pio_main_low_out_ptr = (uint32_t)(data_to_send & 0xFFFFFFFF);   // 发低32位
                    *axi_pio_main_high_out_ptr = (uint32_t)(data_to_send >> 32);         // 发高32位
                    *axi_pio_lw_ifm_wr_ptr = (uint16_t)(i*(original_size+padding_layer*2)+j);
                    if (DEBUG_SEND){
                      printf("ifm write addr: %u\n", (uint16_t)(i*(original_size+padding_layer*2)+j));
                      printf("Integer format: %u\n", (uint32_t)(data_to_send & 0xFFFFFFFF));
                      printf("Bit format:     ");
                      print_bits((uint32_t)(data_to_send & 0xFFFFFFFF));
                      printf("Integer format: %u\n", (uint32_t)(data_to_send >> 32));
                      printf("Bit format:     ");
                      print_bits((uint32_t)(data_to_send >> 32));
                    }
                    sleep(0.1);
                }
            }
            *(axi_pio_lw_ifm_curr_ptr) = 0;
            sleep(0.1);
            *axi_pio_lw_ifm_wr_ptr = (uint16_t)(0);
            sleep(0.1);
            // weight
            *(axi_pio_lw_wet_curr_ptr) = 1;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    //*(axi_pio_lw_valid_ptr) = 0 ;
                    uint64_t data_to_send = 0;
                    for (int imgs = 0; imgs < 8; imgs++) {
                        data_to_send |= ((uint64_t)weight[imgs][i][j]) << (imgs * 8);
                    }
                    *axi_pio_main_low_out_ptr = (uint32_t)(data_to_send & 0xFFFFFFFF);   // 发低32位
                    *axi_pio_main_high_out_ptr = (uint32_t)(data_to_send >> 32);         // 发高32位
                    *axi_pio_lw_wet_wr_ptr = (uint16_t)(i*3+j);
                    if(DEBUG_SEND) {
                      printf("weight write addr: %u\n", (uint16_t)(i*3+j));
                      printf("Integer format: %u\n", (uint32_t)(data_to_send & 0xFFFFFFFF));
                      printf("Bit format:     ");
                      print_bits((uint32_t)(data_to_send & 0xFFFFFFFF));
                      printf("Integer format: %u\n", (uint32_t)(data_to_send >> 32));
                      printf("Bit format:     ");
                      print_bits((uint32_t)(data_to_send >> 32));
                    }
                    

                    //*(axi_pio_lw_valid_ptr) = 1 ;
                    sleep(0.1);
                }
            }
            *(axi_pio_lw_wet_curr_ptr) = 0;
            sleep(0.1);
            *axi_pio_lw_wet_wr_ptr = (uint16_t)(0);
            sleep(0.1);

            *(axi_pio_lw_ifm_done_ptr) = 1;
            sleep(0.1);
            *(axi_pio_lw_ifm_done_ptr) = 0;
            sleep(0.1);
            
            
            if (up_mode) {
              user_threshold = user_threshold + 17;
            } else {
              user_threshold = user_threshold - 17;
            }
            
            if (user_threshold < 4020 && user_threshold > 4000) {
              up_mode = 0;
            } else if (user_threshold > 0 && user_threshold < 20 ) {
              up_mode = 1;
            }
            
            *(axi_pio_lw_thr_ptr) = user_threshold;
            printf("TH: %d\n", user_threshold);
        }
        while (nanosleep(&req, &rem) == -1 && errno == EINTR) req = rem;
    }		
} // end main

/// /// ///////////////////////////////////// 
/// end /////////////////////////////////////