#include <stdio.h>
#include <stdint.h>

#include "data_array.h"


#define padding_layer 1
#define original_size 16  // 原始图像尺寸

uint8_t padded_data[8][original_size + padding_layer * 2][original_size + padding_layer * 2];

void initialize_padded_data() {
    // 初始化所有元素为0
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < original_size + padding_layer * 2; i++) {
            for (int j = 0; j < original_size + padding_layer * 2; j++) {
                padded_data[img][i][j] = 0;
            }
        }
    }

    // 将原始数据复制到padded_data的中心
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < original_size; i++) {
            for (int j = 0; j < original_size; j++) {
                padded_data[img][i + padding_layer][j + padding_layer] = data[img][i][j];
            }
        }
    }
}


void print_padded_data() {
    // 打印第一张图的填充数据
    for (int i = 0; i < original_size + padding_layer * 2; i++) {
        for (int j = 0; j < original_size + padding_layer * 2; j++) {
            printf("%3d ", padded_data[0][i][j]);
        }
        printf("\n");
    }
}

int main() {
    initialize_padded_data();
    print_padded_data();  // 打印填充后的数据
    return 0;
}