// data_array.h
#ifndef INIT_PARAMETER_H
#define INIT_PARAMETER_H

#include <stdint.h>

extern uint8_t size_fm_in;  // 全局可见的数组声明 7bit
extern uint8_t channel_in;  // 全局可见的数组声明 10bit
extern uint8_t channel_out;  // 全局可见的数组声明 11bit
extern uint8_t linebuf_sel;  // 全局可见的数组声明 1bit
extern uint8_t pooling_enable;  // 全局可见的数组声明 1bit
extern uint8_t zero_point_in;  // 全局可见的数组声明 8bit
extern uint8_t zero_point_out;  // 全局可见的数组声明 8bit
extern uint8_t scale;  // 全局可见的数组声明 16bit
extern uint8_t shift;  // 全局可见的数组声明 4bit

#endif // INIT_PARAMETER_H
