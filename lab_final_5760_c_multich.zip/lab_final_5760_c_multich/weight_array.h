// weight_array.h
#ifndef WEIGHT_ARRAY_H
#define WEIGHT_ARRAY_H

#include <stdint.h>

extern int8_t weight[4][8][3][3];  // 全局可见的数组声明

#endif // WEIGHT_ARRAY_H
