// data_array.h
#ifndef DATA_ARRAY_H
#define DATA_ARRAY_H

#include <stdint.h>

extern uint8_t data[2][8][28][28];  // 全局可见的数组声明

#endif // DATA_ARRAY_H
