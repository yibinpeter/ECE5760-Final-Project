// main.c
// #include <png.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "data_array.h"
#include "weight_array.h"


#define padding_layer 1
#define original_size 16  // 原始图像尺寸

int8_t weight[8][3][3];  // 实际定义数组
uint8_t data[8][16][16];  // 实际定义数组
uint8_t padded_data[8][original_size + padding_layer * 2][original_size + padding_layer * 2];

void init_weight(){
    weight[0][0][0] = -1;
    weight[0][0][1] = 0;
    weight[0][0][2] = 1;

    weight[0][1][0] = -2;
    weight[0][1][1] = 0;
    weight[0][1][2] = 2;

    weight[0][2][0] = -1;
    weight[0][2][1] = 0;
    weight[0][2][2] = 1;

    // 初始化数组
    for (int img = 1; img < 8; img++) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                weight[img][i][j] = 0; 
            }
        }
    }
    
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                printf("%d ", weight[img][i][j]);
            }
            printf("\n");
        }
        printf("\n");
    }
}

void initialize_padded_data() {
    // 初始化所有元素为0
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < original_size + padding_layer * 2; i++) {
            for (int j = 0; j < original_size + padding_layer * 2; j++) {
                padded_data[img][i][j] = 0;
            }
        }
    }

    // 将原始数据复制到padded_data的中心
    for (int img = 0; img < 8; img++) {
        for (int i = 0; i < original_size; i++) {
            for (int j = 0; j < original_size; j++) {
                padded_data[img][i + padding_layer][j + padding_layer] = data[img][i][j];
            }
        }
    }
}


void print_padded_data() {
    // 打印第一张图的填充数据
    for (int i = 0; i < original_size + padding_layer * 2; i++) {
        for (int j = 0; j < original_size + padding_layer * 2; j++) {
            printf("%3d ", padded_data[0][i][j]);
        }
        printf("\n");
    }
}

// 定义函数来读取数组
int readArrayFromFile(const char *filename) {
    FILE *file;
    int i, j;

    // 打开文件
    file = fopen(filename, "r");
    if (file == NULL) {
        perror("打开文件失败");
        return 1; // 返回1表示失败
    }

    // 读取数据到二维数组
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 16; j++) {
            if (fscanf(file, "%d", &data[0][i][j]) != 1) {
                perror("文件读取错误");
                fclose(file);
                return 1; // 返回1表示失败
            }
        }
    }

    // 关闭文件
    fclose(file);

    for (int imgs = 1; imgs < 8; imgs++) {
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                data[imgs][i][j] = 0;
            }
        }
    }
    
    return 0; // 返回0表示成功
}


int main() {
    int result;

    // 调用函数读取文件
    result = readArrayFromFile("digit_image_values.txt");
    if (result != 0) {
        printf("读取文件失败\n");
        return 1;
    }

    for (int imgs = 0; imgs < 8; imgs++) {
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                printf("%d ", data[imgs][i][j]);
            }
            printf("\n");
        }
        printf("\n");
    }

    initialize_padded_data();
    print_padded_data();  // 打印填充后的数据
    init_weight();
    return 0;
}